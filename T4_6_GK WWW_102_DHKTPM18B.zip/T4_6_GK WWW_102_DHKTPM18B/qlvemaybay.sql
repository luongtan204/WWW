-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.4.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for qlvemaybay
CREATE DATABASE IF NOT EXISTS `qlvemaybay` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `qlvemaybay`;

-- Dumping structure for table qlvemaybay.chuyenbay
CREATE TABLE IF NOT EXISTS `chuyenbay` (
  `MACHUYEN` char(5) NOT NULL,
  `TENCHUYEN` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `NOIDI` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `NOIDEN` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `NGAYBAY` date DEFAULT NULL,
  PRIMARY KEY (`MACHUYEN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table qlvemaybay.chuyenbay: ~5 rows (approximately)
DELETE FROM `chuyenbay`;
INSERT INTO `chuyenbay` (`MACHUYEN`, `TENCHUYEN`, `NOIDI`, `NOIDEN`, `NGAYBAY`) VALUES
	('CB01', 'VN123', 'Hà Nội', 'TP.HCM', '2025-10-01'),
	('CB02', 'VN456', 'TP.HCM', 'Đà Nẵng', '2025-10-02'),
	('CB03', 'VN789', 'Hà Nội', 'Phú Quốc', '2025-10-03'),
	('CB04', 'VN321', 'Đà Nẵng', 'Cần Thơ', '2025-10-04'),
	('CB05', 'VN654', 'TP.HCM', 'Huế', '2025-10-05');

-- Dumping structure for table qlvemaybay.vemaybay
CREATE TABLE IF NOT EXISTS `vemaybay` (
  `MAVE` char(5) NOT NULL,
  `HOTENHANHKHACH` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `GIAVE` decimal(12,2) DEFAULT NULL,
  `LOAIVE` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MACHUYEN` char(5) DEFAULT NULL,
  PRIMARY KEY (`MAVE`),
  KEY `MACHUYEN` (`MACHUYEN`),
  CONSTRAINT `vemaybay_ibfk_1` FOREIGN KEY (`MACHUYEN`) REFERENCES `chuyenbay` (`MACHUYEN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table qlvemaybay.vemaybay: ~10 rows (approximately)
DELETE FROM `vemaybay`;
INSERT INTO `vemaybay` (`MAVE`, `HOTENHANHKHACH`, `GIAVE`, `LOAIVE`, `MACHUYEN`) VALUES
	('VE01', 'Nguyễn Văn An', 1500000.00, 'Economy', 'CB01'),
	('VE02', 'Trần Thị Bình', 3000000.00, 'Business', 'CB01'),
	('VE03', 'Lê Văn Cường', 1200000.00, 'Economy', 'CB02'),
	('VE04', 'Phạm Thị Dung', 2500000.00, 'Business', 'CB02'),
	('VE05', 'Hoàng Minh Đức', 1800000.00, 'Economy', 'CB03'),
	('VE06', 'Nguyễn Thị Hoa', 3200000.00, 'Business', 'CB03'),
	('VE07', 'Lê Quốc Huy', 1100000.00, 'Economy', 'CB04'),
	('VE08', 'Võ Thị Lan', 2200000.00, 'Business', 'CB04'),
	('VE09', 'Phạm Văn Nam', 1600000.00, 'Economy', 'CB05'),
	('VE10', 'Ngô Thị Oanh', 2800000.00, 'Business', 'CB05');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
